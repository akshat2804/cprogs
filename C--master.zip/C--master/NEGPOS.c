#include <stdio.h> 
#include<conio.h> 
 void main()  
{  
    int n;    
printf("enter a number:");    
scanf("%d",&n);     
if(n>0)
{    
printf("the number is positive");    
}    
else if(n<0)
{    
printf("the number is negative");    
}    
else
{    
printf("the number is 0");    
}     
    getch();
    }
