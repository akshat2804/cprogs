#include <stdio.h> 
#include<conio.h> 
 void main()  
{  
    int a,b,c;    
printf("enter first angle");    
scanf("%d",&a);  
printf("enter second angle");    
scanf("%d",&b);    
 printf("enter third angle");    
scanf("%d",&c);        
if(a+b+c==180)
{    
printf("it is a triangle");    
}    
else
{    
printf("it is not a triangle");    
}     
    getch();
    }
