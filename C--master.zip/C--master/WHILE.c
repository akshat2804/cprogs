#include<stdio.h>
#include<conio.h>
void main()
{
	int n=1;
	while(n<100)
	{
		printf("\n %d",n);
		n++;
	}
getch();
}
