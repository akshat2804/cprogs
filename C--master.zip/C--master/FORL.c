#include<stdio.h>
#include<conio.h>
void main()
{
	int n;
	for(n=1;n<100;n++)
	{
		printf("\n %d",n);
	}
getch();
}
